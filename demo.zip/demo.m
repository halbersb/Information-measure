load('DBs\syntheticsize_500numclass4db\syntheticsize_500numclass4dbp0f0.mat');
num_folds_k=4;
init_type='NBC';

%here we run the regular rmcv
[results_acc,mats_acc] = extended_rmcv(mytrain_data,mytest_data,CLASS,num_folds_k,init_type,'ACC');
disp('The rmcv-based ACC confusion matrix is:');
disp(mats_acc{1,2});

%here we run the rmcv based IMalpha (with alpha=2)
[results_imalpha,mats_imalpha] = extended_rmcv(mytrain_data,mytest_data,CLASS,num_folds_k,init_type,'IMalpha',2);
disp('The rmcv-based IMalpha confusion matrix is:');
disp(mats_imalpha{1,2});